import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import UseStorageState from "../servicios/UseStorageState";
import "../estilos/menu.css";

const usuarios = [
  { usuario: "admin", password: "12345" }
];

const MenuSuperior = ({ juegosCarrito, setJuegosCarrito }) => {
  const [carritoVisible, setCarritoVisible] = useState(false);
  const [loginVisible, setLoginVisible] = useState(false);
  const [usuario, setUsuario] = UseStorageState("usuario", ""); 
  const [nombreUsuario, setNombreUsuario] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const toggleCarrito = () => {
    setCarritoVisible(!carritoVisible);
  };

  const eliminarProducto = (id) => {
    const juegosFiltrados = juegosCarrito.filter(juego => juego.id !== id);
    setJuegosCarrito(juegosFiltrados);
  };

  const toggleLogin = () => {
    setLoginVisible(!loginVisible);
  };

  const manejarLogin = (e) => {
    e.preventDefault();
    const usuarioEncontrado = usuarios.find(
      (u) => u.usuario === nombreUsuario && u.password === password
    );

    if (usuarioEncontrado) {
      setUsuario(nombreUsuario); 
      setLoginVisible(false);
      setNombreUsuario("");
      setPassword("");
      navigate("/");
    } else {
      alert("Usuario o contraseña incorrectos");
    }
  };

  const cerrarSesion = () => {
    setUsuario(""); 
    navigate("/");
  };

  return (
    <div className="barraSuperior">
      <div className="menuIzquierda">
        <div className="zonaLogo">
          <img src="/imagenes/logo.png" className="logo" alt="Logo de PC Games" />
          <p>PC Games</p>
        </div>
      </div>
      <div className="menuMedio">
        <ul className="linksMenu">
          <li>
            <Link to="/" className="link">TIENDA</Link>
          </li>
          <li>
            <Link to="/biblioteca" className="link">BIBLIOTECA</Link>
          </li>
          {usuario === "admin" && (
            <li>
              <Link to="/admin" className="link">ADMIN</Link>
            </li>
          )}
        </ul>
      </div>
      <div className="menuDerecha">
        <ul className="linksMenu">
            <li>
            {usuario ? (
              <button className="boton-logout" onClick={cerrarSesion}>
                Cerrar Sesión ({usuario})
              </button>
            ) : (
              <button className="boton-login" onClick={toggleLogin}>
                Acceder al admin
              </button>
            )}
          </li>
          <Link to="/detalleCarrito" className="link">
            <li className="link"><p>CARRITO</p></li>
          </Link>
          <li>
            <button className="toggle-carrito" onClick={toggleCarrito}>
              🛒
            </button>
          </li>
          
        </ul>
      </div>

      {carritoVisible && (
        <div className="carrito-productos">
          <h4>Carrito</h4>
          {juegosCarrito.length > 0 ? (
            <ul className="lista-productos">
              {juegosCarrito.map((producto, index) => (
                <li key={index} className="producto-item">
                  <span>{producto.nombre}</span>
                  <button
                    className="eliminar-producto"
                    onClick={() => eliminarProducto(producto.id)}
                  >
                    🗑️
                  </button>
                </li>
              ))}
              <li>
                <Link to="/detalleCarrito" className="annadirCarrito2">Ir al carrito</Link>
              </li>
            </ul>
          ) : (
            <p>No hay productos en el carrito.</p>
          )}
        </div>
      )}

      {loginVisible && (
        <div className="ventana-login">
          <h3>Iniciar Sesión</h3>
          <form onSubmit={manejarLogin}>
            <input
              type="text"
              placeholder="Usuario"
              value={nombreUsuario}
              onChange={(e) => setNombreUsuario(e.target.value)}
            />
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit">Ingresar</button>
            <button type="button" onClick={toggleLogin}>Cancelar</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default MenuSuperior;
