import React from "react";
import { FaTimes } from "react-icons/fa";
import "../estilos/modalConsulta.css"; 

const ConsultarJuego = ({ juego, cerrarModalConsultar }) => {
  if (!juego) return null; 

  return (
    <div className="modal-overlay-consulta">
      <div className="modal-container-consulta">

        <button className="modal-close-button-consulta" onClick={cerrarModalConsultar}>
          <FaTimes size={20} />
        </button>

        <img src={juego.url} alt={juego.nombre} className="modal-image-consulta" />

        <div className="modal-info-consulta">
          <h2 className="modal-title-consulta">{juego.nombre}</h2>
          <p className="modal-description-consulta">{juego.descripcion}</p>

          <p className="m">
            <strong>Precio:</strong>
          </p>
          <p className="modal-price-consulta">
            {juego.precio ? `${juego.precio}€` : "Gratis"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConsultarJuego;
