import React, { useState } from "react";
import { FaTrash, FaEdit, FaEye, FaPlus } from "react-icons/fa";
import "../estilos/admin.css";
import ServicioInformacion from "../servicios/axios/ServicioInformacion";
import ConsultarJuego from "./consultarJuego";
import EditarJuego from "./editarJuego";
import CrearJuego from "./CrearJuego";
import Modal from "./Modal";

const Administrador = ({ informacion, setInformacion, juegosComprados, setJuegosComprados, juegosCarrito, setJuegosCarrito }) => {
  const [juegoSeleccionado, setJuegoSeleccionado] = useState(null);
  const [modalConsultarAbierto, setModalConsultarAbierto] = useState(false);
  const [modalEditarAbierto, setModalEditarAbierto] = useState(false);
  const [modalCrearAbierto, setModalCrearAbierto] = useState(false);

  const abrirModalCrear = () => setModalCrearAbierto(true);
  const cerrarModalCrear = () => setModalCrearAbierto(false);
  const cerrarModalConsultar = () => {
    setJuegoSeleccionado(null);
    setModalConsultarAbierto(false);
  };
  const cerrarModalEditar = () => {
    setJuegoSeleccionado(null);
    setModalEditarAbierto(false);
  };

  const eliminarJuego = (id) => {
    ServicioInformacion.borrarElemento(id)
      .then(() => {
        setInformacion(informacion.filter((elemento) => elemento.id !== id));
        setJuegosComprados(juegosComprados.filter((elemento) => elemento.id !== id));
        setJuegosCarrito(juegosCarrito.filter((elemento) => elemento.id !== id));
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "No se ha podido eliminar el elemento..."
        });
        console.error(error);
      });
  };

  const editarJuego = (juego) => {
    setJuegoSeleccionado(juego);
    setModalEditarAbierto(true);
  };

  const consultarJuego = (juego) => {
    setJuegoSeleccionado(juego);
    setModalConsultarAbierto(true);
  };

  return (
    <div className="admin">
      <h2>Administrador de Juegos</h2>
      <button onClick={abrirModalCrear} className="crear">
        <FaPlus /> Crear Juego
      </button>
      <div className="lista-juegos">
        {informacion.length === 0 ? (
          <p>No hay juegos disponibles.</p>
        ) : (
          informacion.map((juego) => (
            <div key={juego.id} className="juego-card">
              <img src={juego.url} alt={juego.nombre} />
              <div className="info">
                <h3>{juego.nombre}</h3>
                <div className="botones">
                  <button onClick={() => consultarJuego(juego)} className="consultar">
                    <FaEye /> Consultar
                  </button>
                  <button onClick={() => editarJuego(juego)} className="editar">
                    <FaEdit /> Editar
                  </button>
                  <button onClick={() => eliminarJuego(juego.id)} className="eliminar">
                    <FaTrash /> Eliminar
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <Modal isOpen={modalConsultarAbierto} onClose={cerrarModalConsultar}>
        {juegoSeleccionado && <ConsultarJuego juego={juegoSeleccionado} cerrarModalConsultar={cerrarModalConsultar} />}
      </Modal>

      <Modal isOpen={modalEditarAbierto} onClose={cerrarModalEditar}>
        {juegoSeleccionado && <EditarJuego juego={juegoSeleccionado} setInformacion={setInformacion} setJuegosComprados={setJuegosComprados} setJuegosCarrito={setJuegosCarrito} cerrarModalEditar={cerrarModalEditar} />}
      </Modal>

      <Modal isOpen={modalCrearAbierto} onClose={cerrarModalCrear}>
        <CrearJuego setInformacion={setInformacion} cerrarModalCrear={cerrarModalCrear}/>
      </Modal>
    </div>
  );
};

export default Administrador;
