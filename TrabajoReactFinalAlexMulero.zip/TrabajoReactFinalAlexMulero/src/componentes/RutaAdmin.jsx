import { Navigate } from "react-router-dom"; //Navigate se usa para redirigir a otra ruta si el usuario no cumple con los requisitos.
import UseStorageState from "../servicios/UseStorageState";

const RutaAdmin = ({ children }) => {
  const [usuario] = UseStorageState("usuario", ""); 

  return usuario === "admin" ? children : <Navigate to="/" />;
};

export default RutaAdmin;
