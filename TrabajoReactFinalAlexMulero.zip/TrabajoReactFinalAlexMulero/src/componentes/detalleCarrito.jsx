import React from "react";

import "../estilos/detallecarrito.css";
import { Link } from "react-router-dom";

import Swal from "sweetalert2";

const DetalleCarrito = ({ juegosComprados, setJuegosComprados,juegosCarrito, setJuegosCarrito }) => {


    const eliminarJuego = (id) => {
        const nuevosJuegos = juegosCarrito.filter((juego) => juego.id !== id);
        setJuegosCarrito(nuevosJuegos);
    };

    const comprar = () => {
        if (juegosCarrito.length === 0) {
            Swal.fire({
                icon: "warning",
                title: "Carrito vacío",
                text: "No tienes juegos en el carrito.",
            });
            return;
        }

        

        setJuegosComprados([...juegosComprados, ...juegosCarrito]); 
        setJuegosCarrito([]); 
    
        Swal.fire({
            icon: "success",
            title: "¡Compra realizada!",
            text: "Tus juegos han sido añadidos a la biblioteca.",
            confirmButtonColor: "#4b6910",
        });
    };

    const totalPrecio = juegosCarrito.reduce((total, juego) => total + juego.precio, 0);

    return (
        <div className="detalle-carrito">
            <h2>Tu carrito de compras</h2>

            {juegosCarrito.length === 0 ? (
                <p className="carrito-vacio">Tu carrito está vacío</p>
            ) : (
                <div className="tabla-carrito">
                    <table>
                        <thead>
                            <tr>
                                <th>Juego</th>
                                <th>Precio</th>
                                <th>Quitar</th>
                            </tr>
                        </thead>
                        <tbody>
                            {juegosCarrito.map((juego) => (
                                <tr key={juego.id}>
                                    <td className="juego-info">
                                        <img src={juego.url} alt={juego.nombre} className="juego-img" />
                                        <span>{juego.nombre}</span>
                                    </td>
                                    <td className="precio">{juego.precio.toFixed(2)}€</td>
                                    <td>
                                        <button className="eliminar-btn" onClick={() => eliminarJuego(juego.id)}>✖</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {juegosCarrito.length > 0 && (
                <div className="total-container">
                    <span className="total-precio">Total: {totalPrecio.toFixed(2)}€</span>
                    <button className="boton-comprar" onClick={() => comprar()}>Comprar</button>
                </div>
            )}

            <Link to="/" className="boton-volver">⬅ Volver a la tienda</Link>
        </div>
    );
};

export default DetalleCarrito;
