import React, { useState } from "react";
import ServicioInformacion from "../servicios/axios/ServicioInformacion";
import Swal from "sweetalert2";
import "../estilos/crearJuego.css";

const CrearJuego = ({ setInformacion, cerrarModalCrear }) => {
    const [form, setForm] = useState({
        nombre: "",
        precio: "",
        descripcion: "",
        url: "",
    });

    const gestionarCambio = (e) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]: name === "precio" ? parseFloat(value) || "" : value,
        });
    };

    const enviarFormulario = (e) => {
        e.preventDefault();

        ServicioInformacion.getAll()
            .then((response) => {
                const juegos = response.data;

                const idsNumericos = juegos
                    .map(juego => Number(juego.id))
                    .filter(id => !isNaN(id));

                const ultimoId = idsNumericos.length > 0 ? Math.max(...idsNumericos) : 0;
                const nuevoId = ultimoId + 1;

                const nuevoJuego = {
                    id: nuevoId.toString(),
                    nombre: form.nombre,
                    precio: parseFloat(form.precio), 
                    descripcion: form.descripcion,
                    url: `/imagenes/${form.url}`,
                };


                return ServicioInformacion.crearElemento(nuevoJuego);
            })

            .then((response) => {
                Swal.fire({
                    icon: "success",
                    title: "Juego creado",
                    text: "El juego ha sido agregado correctamente."
                });

                setInformacion((prevJuegos) => [...prevJuegos, response.data]);

                cerrarModalCrear();
            })
            .catch((error) => {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "No se ha podido agregar el juego."
                });
                console.error(error);
            });
    };


    return (
        <div className="crearForm">
            <form onSubmit={enviarFormulario}>
                <label htmlFor="nombre">Nombre</label>
                <input
                    id="nombre"
                    type="text"
                    name="nombre"
                    value={form.nombre}
                    onChange={gestionarCambio}
                    placeholder="Escribe el nombre"
                    required
                />

                <label htmlFor="precio">Precio</label>
                <input
                    id="precio"
                    type="number"
                    step="0.01"
                    name="precio"
                    value={form.precio}
                    onChange={gestionarCambio}
                    placeholder="Precio"
                    required
                />


                <label htmlFor="descripcion">Descripción</label>
                <textarea
                    id="descripcion"
                    name="descripcion"
                    value={form.descripcion}
                    onChange={gestionarCambio}
                    placeholder="Escribe la descripción aquí..."
                    rows="4"
                    required
                    className="textarea-descripcion"
                />

                <label htmlFor="url">URL de la Imagen</label>
                <input
                    id="url"
                    type="text"
                    name="url"
                    value={form.url}
                    onChange={gestionarCambio}
                    placeholder="Ejemplo: juego.jpg"
                    required
                />

                <button type="submit">Crear</button>
            </form>
        </div>
    );
};

export default CrearJuego;
